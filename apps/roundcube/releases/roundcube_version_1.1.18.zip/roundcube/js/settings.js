$(document).ready(function() {
	// enable tabs on settings page
	$('#roundcube').tabs();
});

