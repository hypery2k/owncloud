<?php $TRANSLATIONS = array(
"RoundCube Mailaccount" => "RoundCube Emailkonto",
"RoundCube Settings" => "RoundCube Webmail Einstellungen",
"Basic settings" => "Grundeinstellungen",
"Advanced settings" => "Erweiterte Einstellungen",
"Relative URL to roundcube installation, e.g. If you have http://example.com/roundcube enter /roundcube/ here. Note that subdomains do not work, just relative URLs to the same domain owncloud is running" => "URL des Roundcube Servers, z.B. Bei https://owncloud.com/roundcube wäre das /roundcube/. Es funktionieren nur relative Pfadangaben, die sich auf diesselbe Domain beziehen wie die auf der Owncloud läuft.",
"Roundcube version" => "Roundcube Version",
"Remove RoundCube control navigation menu items" => "Navigationsleiste ausblenden",
"Remove RoundCube header navigation menu items" => "RoundCube Navigationselemente ausblenden",
"Name" => "Name",
"Share" => "Teilen",
"Download" => "Herunterladen",
"Delete" => "Löschen",
"You don't have any email account configured yet." => "Bitte richten Sie zunächst ein Emailkonto ein.",
"You don't have any email account in ot configured correctly yet. Please check you username and password." => "Bitte richten Sie zunächst ihr Emailkonto korrekt ein. Überprüfen sie Nutzer und Passwort.",
"Logged in as " => "Angemeldet als "
); 
