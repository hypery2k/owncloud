<?php $TRANSLATIONS = array(
"RoundCube Mailaccount" => "RoundCube Emailkonto",
"RoundCube Settings" => "RoundCube Webmail Einstellungen",
"Basic settings" => "Grundeinstellungen",
"Advanced settings" => "Erweiterte Einstellungen",
"Roundcube directory" => "Roundcube Verzeichnis",
"Roundcube version" => "Roundcube Version",
"Remove RoundCube header navigation menu items" => "Obere RoundCube Navigationselemente entfernen",
"Name" => "Name",
"Share" => "Teilen",
"Download" => "Herunterladen",
"Delete" => "Löschen"
);
