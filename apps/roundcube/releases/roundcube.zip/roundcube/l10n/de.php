<?php $TRANSLATIONS = array(
"RoundCube Mailaccount" => "RoundCube Emailkonto",
"RoundCube Settings" => "RoundCube Webmail Einstellungen",
"Basic settings" => "Grundeinstellungen",
"Advanced settings" => "Erweiterte Einstellungen",
"URL to rouncube installation, e.g. https://owncloud.com/roundcube" => "URL des Roundcube Servers, z.B. https://owncloud.com/roundcube",
"Roundcube version" => "Roundcube Version",
"Remove RoundCube header navigation menu items" => "Obere RoundCube Navigationselemente entfernen",
"Name" => "Name",
"Share" => "Teilen",
"Download" => "Herunterladen",
"Delete" => "Löschen"
);
