<div id="dberror">
    <h1><?php echo $l->t("Database error") ?></h1>
    <div>
        <small><?php echo $l -> t('Please follow the wiki page to setup the database manually:') ?></small>
	    <a class="button" target="_blank" href="https://github.com/hypery2k/owncloud/wiki/Installation#manual-database-configuration">Wiki</a>
	</div>
</div>
