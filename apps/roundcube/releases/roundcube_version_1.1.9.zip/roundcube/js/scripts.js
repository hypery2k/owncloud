// dirty fix for JS errors
$.fn.extend({showPassword: function(c) {  }});
$.fn.extend({inFieldLabels: function(d) {  }});
$.fn.extend({tipsy: function(e) {  }});